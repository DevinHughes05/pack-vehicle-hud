-- fxmanifest.lua

fx_version 'bodacious'
game 'gta5'

author 'WolfPack Development'
description 'Customizable Vehicle HUD displaying speed, fuel, and engine health.'
version '1.0.0'

client_script 'hud_main.lua'
